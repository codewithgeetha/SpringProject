package org.example.SpringBootSampleTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSampleTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSampleTestApplication.class, args);
	}

}
