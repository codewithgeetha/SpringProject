package org.example.SpringBootSampleTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSampleTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
