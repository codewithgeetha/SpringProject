package com.amazon.amazon_backend.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class OrderItem {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //
    @ManyToOne
    @JoinColumn(name ="order_id") //frn key many to one on orders
    @JsonIgnore
    private Order order;       //used to track items on orders


    @ManyToOne
    @JoinColumn(name= "product_id")
    private Product product;

    private Long orderedQuantity;
}
