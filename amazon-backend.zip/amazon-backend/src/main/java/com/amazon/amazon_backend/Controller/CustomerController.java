package com.amazon.amazon_backend.Controller;


import com.amazon.amazon_backend.model.Customer;
import com.amazon.amazon_backend.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {


    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public Customer registerCustomer(@RequestBody Customer customer){

        return customerService.registerCustomer(customer);

    }

    //todo: api to update phone or anything you like
    @PutMapping("/updatePhone/{cId}")
    public Customer updatePhoneNumber(@PathVariable Long cId, @RequestBody String phoneNumber) {
        return customerService.updatePhoneNumber(cId, phoneNumber);

    }
}
