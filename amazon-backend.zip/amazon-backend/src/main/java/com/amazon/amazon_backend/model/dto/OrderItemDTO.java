package com.amazon.amazon_backend.model.dto;

import com.amazon.amazon_backend.model.Address;
import com.amazon.amazon_backend.model.Payment;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@Getter
@Setter
public class OrderItemDTO {

    private Long productId;

    private Long requestedQuantity;
}
