package com.amazon.amazon_backend.model;

public enum Status {

    CREATED,

    PROCESSING,

    SHIPPED,

    CANCELLED,

    DELIVERED;


}
