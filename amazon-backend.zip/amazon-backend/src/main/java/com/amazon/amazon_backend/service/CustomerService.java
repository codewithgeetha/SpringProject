package com.amazon.amazon_backend.service;

import com.amazon.amazon_backend.model.Customer;

public interface CustomerService {

    Customer registerCustomer(Customer c);

    Customer updatePhoneNumber(Long cId, String newNumber);
}
