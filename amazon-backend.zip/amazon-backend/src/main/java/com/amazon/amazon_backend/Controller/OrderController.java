package com.amazon.amazon_backend.Controller;


import com.amazon.amazon_backend.exception.CustomerNotFoundException;
import com.amazon.amazon_backend.model.Order;
import com.amazon.amazon_backend.model.dto.OrderRequestDTO;
import com.amazon.amazon_backend.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class OrderController {


@Autowired
private OrderService orderService;

@PostMapping("/create")
public Order createOrder(@RequestBody OrderRequestDTO request) throws CustomerNotFoundException {

    Order order = orderService.createOrder(request);
return order;
    }

    //todo: cancel an order


    //todo: status of an order
    //todo: update  shipping adress
}
