package com.amazon.amazon_backend.service.impl;

import com.amazon.amazon_backend.model.Customer;
import com.amazon.amazon_backend.repository.CustomerRepository;
import com.amazon.amazon_backend.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {

@Autowired
private CustomerRepository customerRepository;


    @Override
    public Customer registerCustomer(Customer c) {

        Customer saved = customerRepository.save(c);


        return saved;
    }

    @Override
    public Customer updatePhoneNumber(Long cId, String newNumber) {
        Optional<Customer> customerOptional = customerRepository.findById(cId);

        if (customerOptional.isPresent()) {
            Customer customer = customerOptional.get();
            customer.setPhoneNumber(newNumber); // Assuming phoneNumber exists in Customer entity
            return customerRepository.save(customer);
        } else {
            throw new RuntimeException("Customer not found with ID: " + cId);
        }

    }
}
