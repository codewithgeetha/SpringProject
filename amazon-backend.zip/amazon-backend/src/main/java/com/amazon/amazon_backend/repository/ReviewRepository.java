package com.amazon.amazon_backend.repository;

import com.amazon.amazon_backend.model.Review;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ReviewRepository extends CrudRepository<Review, Long> {
}
