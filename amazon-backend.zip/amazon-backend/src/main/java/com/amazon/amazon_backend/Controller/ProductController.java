package com.amazon.amazon_backend.Controller;


import com.amazon.amazon_backend.model.Product;
import com.amazon.amazon_backend.model.Review;
import com.amazon.amazon_backend.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {


    @Autowired
    private ProductService productService;

    @PostMapping("/onboard")
public Product onboardProduct(@RequestBody Product product){

    Product saved = productService.onboardProduct(product);
    return  saved;

}

//todo: api for stock up



    // todo : adding review to product
// API to add review to product
@PostMapping("/{productId}/addReview")
public Product addReview(@PathVariable Long productId, @RequestBody Review review) {
    return productService.addReview(productId, review);
}
}
