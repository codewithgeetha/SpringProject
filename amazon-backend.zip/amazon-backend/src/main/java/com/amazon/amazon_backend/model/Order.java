package com.amazon.amazon_backend.model;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name= "orders")
@Getter
@Setter
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

     private LocalDateTime createdAt;


    @Enumerated(value = EnumType.STRING) // we are telling that consider it as an value
    private Status status; // enum is Status


    //keeping one to one relation with address to keep it simple, and order is deleted adress also deleted
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id")
    private Address ShippingAddress;


    //the relation many to one from order side
    //froeign key on manyside
    @ManyToOne
    @JoinColumn(name= "customer_id")
    private Customer customer;



    // set of order items, one to many because order having many items
    @OneToMany(mappedBy = "order", cascade =  CascadeType.ALL)
    private Set<OrderItem> items = new HashSet<>();


    //with payment
@OneToOne(cascade = CascadeType.ALL)
@JoinColumn(name ="payment_id")
private Payment payment;

    private Double subTotal;

    private Double Tax;


    private Double shippingCharges;

    private Double totalPrice;
}
