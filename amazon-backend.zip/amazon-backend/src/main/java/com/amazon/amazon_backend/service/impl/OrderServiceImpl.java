package com.amazon.amazon_backend.service.impl;

import com.amazon.amazon_backend.exception.CustomerNotFoundException;
import com.amazon.amazon_backend.model.*;
import com.amazon.amazon_backend.model.dto.OrderItemDTO;
import com.amazon.amazon_backend.model.dto.OrderRequestDTO;
import com.amazon.amazon_backend.repository.CustomerRepository;
import com.amazon.amazon_backend.repository.OrderRepository;
import com.amazon.amazon_backend.repository.ProductRepository;
import com.amazon.amazon_backend.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;


@Service
public class OrderServiceImpl implements OrderService {



    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Order createOrder(OrderRequestDTO request) throws CustomerNotFoundException {
        Long cID = request.getCustomerId();
        Optional<Customer> customerOptional= customerRepository.findById(cID);


        if (customerOptional. isEmpty()){
throw new CustomerNotFoundException(" customer with id: "+ cID + " is not found");
        }

Customer customer = customerOptional.get();

        Order order  = new Order();

order.setCustomer(customer);
order.setCreatedAt(LocalDateTime.now());
order.setStatus(Status.CREATED);
order.setShippingAddress(request.getShippingAddress());
Set<OrderItem> items = new HashSet<>();


//todo : calculate prices includes subtotal, taxable
// check if you have requested quantity or not, if not throw exception(http response)
// extra points: adjusting the product availability(after creating order)
for (OrderItemDTO item : request.getItems()){
    Long pId = item.getProductId();
    Optional<Product> productOptional = productRepository.findById(pId);
    if(productOptional.isEmpty()){
    //to do : product not found error with 404 exception
}
   Product p = productOptional.get();

OrderItem oItem = new OrderItem();
oItem.setProduct(p);
oItem.setOrderedQuantity(item.getRequestedQuantity());
oItem.setOrder(order);


items.add(oItem);
}

order.setItems(items);



String confirmationCode = processPayment(request.getPayment());
Payment payment = request.getPayment();
payment.setReferenceCode(confirmationCode);
order.setPayment(payment);

      Order saved =  orderRepository.save(order);
      return saved;


    }

    private String  processPayment(Payment payment){
        System.out.println("making an visa payment gateway call");
        return "ABC1234";
    }

    @Override
    public void cancelOrder(Long id) {

    }

    @Override
    public void trackOrder(Long id) {

    }

    @Override
    public void changeShipmentAddress(Long id, Address address) {

    }
}
