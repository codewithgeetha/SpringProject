package com.amazon.amazon_backend.service;

import com.amazon.amazon_backend.exception.CustomerNotFoundException;
import com.amazon.amazon_backend.model.Address;
import com.amazon.amazon_backend.model.Order;
import com.amazon.amazon_backend.model.dto.OrderRequestDTO;

public interface OrderService {


    Order createOrder(OrderRequestDTO request) throws CustomerNotFoundException;

    void cancelOrder(Long id);

    void trackOrder(Long id);

    void changeShipmentAddress(Long id, Address address);
}
