package com.amazon.amazon_backend.exception;

// todo: checked or unchecked i should decide
public class CustomerNotFoundException extends Exception{


    public CustomerNotFoundException(String message) {
        super(message);
    }
}
