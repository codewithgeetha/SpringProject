package com.amazon.amazon_backend.service.impl;

import com.amazon.amazon_backend.model.Product;
import com.amazon.amazon_backend.model.Review;
import com.amazon.amazon_backend.repository.ProductRepository;
import com.amazon.amazon_backend.repository.ReviewRepository;
import com.amazon.amazon_backend.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Optional;
import java.util.Set;
//we can implement methods  directly by implementing

@Service
public class ProductServiceImpl implements ProductService {




    @Autowired
    private ProductRepository productRepository;


    @Autowired
    private ReviewRepository reviewRepository;


    // from productcnroller we are getting all the details of product
    @Override
    public Product onboardProduct(Product product) {

        if (product.getUnitPrice() <= 0){
            throw new IllegalArgumentException("Unit Price should be greater than Zero");
        }
        Product saved = productRepository.save(product);
        return saved;
    }



    public Product addReview(Long productId, Review review) {
        Optional<Product> productOptional = productRepository.findById(productId);

        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            review.setProduct(product); // Establish relationship
            reviewRepository.save(review); // Save review
            return productRepository.findById(productId).get(); // Return updated product
        } else {
            throw new RuntimeException("Product not found with ID: " + productId);
        }
    }


    @Override
    public Product stockUpProduct(Long pId, Long newQuantity) {

        //to
        return null;
    }
}



