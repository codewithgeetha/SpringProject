package com.amazon.amazon_backend.service;

import com.amazon.amazon_backend.model.Product;
import com.amazon.amazon_backend.model.Review;

public interface ProductService {

    Product onboardProduct(Product product);

    Product stockUpProduct(Long pId, Long newQuantity);

    //Review addReview(Long pId, Review r);

    Product addReview(Long productId, Review review);
}
