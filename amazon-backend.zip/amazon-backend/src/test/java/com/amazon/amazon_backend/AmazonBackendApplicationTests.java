package com.amazon.amazon_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
